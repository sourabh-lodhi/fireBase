// const { defineString } = require('firebase-functions/params')

// export const JWT_SECRET_KEY = defineString('JWT_SECRET_KEY')
// export const TWILIO_ACCOUNT_SID = defineString('TWILIO_ACCOUNT_SID')
// export const TWILIO_AUTH_TOKEN = defineString('TWILIO_AUTH_TOKEN')
// export const TWILIO_PHONE_NUMBER = defineString('TWILIO_PHONE_NUMBER')
// export const SENDGRID_API_KEY = defineString('SENDGRID_API_KEY')
// export const SENDGRID_SENDER_EMAIL = defineString('SENDGRID_SENDER_EMAIL')

// export const JWT_SECRET_KEY = process.env.JWT_SECRET_KEY
// export const TWILIO_ACCOUNT_SID = process.env.TWILIO_ACCOUNT_SID
// export const TWILIO_AUTH_TOKEN = process.env.TWILIO_AUTH_TOKEN
// export const TWILIO_PHONE_NUMBER = process.env.TWILIO_PHONE_NUMBER
// export const SENDGRID_API_KEY = process.env.SENDGRID_API_KEY
// export const SENDGRID_SENDER_EMAIL = process.env.SENDGRID_SENDER_EMAIL

export const JWT_SECRET_KEY="DESFRCSEVSSDWRCSCRVSRV"
export const TWILIO_ACCOUNT_SID="ACda51a32b719d3f2d24778dfafce40c29"
export const TWILIO_AUTH_TOKEN="dfe4d82f4faf1c87ae8bba77f65d89d3"
export const TWILIO_PHONE_NUMBER="+12177491180"
export const SENDGRID_API_KEY=""
export const SENDGRID_SENDER_EMAIL=""


